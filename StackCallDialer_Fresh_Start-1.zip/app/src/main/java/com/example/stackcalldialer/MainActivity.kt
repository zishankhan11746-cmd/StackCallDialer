package com.example.stackcalldialer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private val permissionRequest = 42
    private lateinit var callList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createUi()
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
            loadCalls()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS), permissionRequest)
        }
    }

    private fun createUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 12)
            setBackgroundColor(0xFFF2F4F8.toInt())
        }
        root.addView(TextView(this).apply {
            text = "StackCallDialer"
            textSize = 26f
            setTextColor(0xFF111827.toInt())
            gravity = Gravity.START
            setPadding(4, 4, 4, 16)
        })
        root.addView(TextView(this).apply {
            text = "Recent calls"
            textSize = 16f
            setTextColor(0xFF5B6472.toInt())
            setPadding(4, 0, 4, 12)
        })
        callList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(callList) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) loadCalls()
        else showMessage("Allow call-log permission to display recent calls.")
    }

    private fun loadCalls() {
        callList.removeAllViews()
        val projection = arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE, CallLog.Calls.TYPE)
        val seen = mutableSetOf<String>()
        try {
            val cursor: Cursor? = contentResolver.query(CallLog.Calls.CONTENT_URI, projection, null, null, "${CallLog.Calls.DATE} DESC")
            var count = 0
            cursor?.use {
                while (it.moveToNext() && count < 30) {
                    val number = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.NUMBER)) ?: "Unknown"
                    val key = number.ifBlank { "Unknown" }
                    if (!seen.add(key)) continue
                    val name = it.getString(it.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME))?.takeIf { s -> s.isNotBlank() } ?: key
                    val date = it.getLong(it.getColumnIndexOrThrow(CallLog.Calls.DATE))
                    val type = it.getInt(it.getColumnIndexOrThrow(CallLog.Calls.TYPE))
                    addCard(name, key, date, type)
                    count++
                }
            }
            if (count == 0) emptyState("No recent calls found.")
        } catch (_: Exception) {
            emptyState("Unable to read calls. Check permissions.")
        }
    }

    private fun addCard(name: String, number: String, date: Long, type: Int) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(0xFFFFFFFF.toInt())
            elevation = 5f
        }
        card.addView(TextView(this).apply { text = name; textSize = 18f; setTextColor(0xFF172033.toInt()) })
        card.addView(TextView(this).apply {
            text = "$number  •  ${typeLabel(type)}"
            textSize = 14f
            setTextColor(0xFF596579.toInt())
            setPadding(0, 4, 0, 4)
        })
        card.addView(TextView(this).apply {
            text = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(date))
            textSize = 12f
            setTextColor(0xFF7B8494.toInt())
        })
        card.setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))) }
            catch (_: Exception) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))) }
        }
        callList.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(4, 0, 4, -18) })
    }

    private fun typeLabel(type: Int) = when (type) {
        CallLog.Calls.INCOMING_TYPE -> "Incoming"
        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
        CallLog.Calls.MISSED_TYPE -> "Missed"
        CallLog.Calls.REJECTED_TYPE -> "Rejected"
        else -> "Call"
    }

    private fun emptyState(message: String) {
        callList.addView(TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(0xFF596579.toInt())
            setPadding(12, 24, 12, 24)
        })
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        emptyState(message)
    }
}
