# StackCallDialer

Fresh Android Kotlin project prototype showing recent calls as overlapping cards.

## Build
Requires JDK 17, Android SDK platform 35, and Gradle 8.7.
From the project root run:
`gradle --no-daemon clean assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

Both Java and Kotlin JVM targets are set to 17 in `app/build.gradle`.

This is a prototype, not a complete default-dialer replacement; Android may require default dialer role handling for full dialer functionality.
