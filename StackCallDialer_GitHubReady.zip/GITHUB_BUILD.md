# Build StackCallDialer on GitHub

Upload this project to a GitHub repository, then open **Actions** and run
**Build StackCallDialer APK**. The workflow installs JDK 17 and Gradle 8.7
on GitHub's runner and uploads `app-debug.apk` as an artifact.
