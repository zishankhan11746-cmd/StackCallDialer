# Stack Call Dialer

A small Android project that displays recent calls as overlapping white cards, inspired by the user's reference image.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

The app requests READ_CALL_LOG, READ_CONTACTS and CALL_PHONE permissions. It is a prototype, not a replacement for the system Phone app.

## Important
The current prototype groups repeated numbers into one visible stack card. It is intentionally lightweight for older Samsung devices such as the Galaxy M21.
