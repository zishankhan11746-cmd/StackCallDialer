# StackCallDialer - corrected build package

This project is prepared for a standard Android Gradle build.

## Required
- Android SDK Platform 35
- Android SDK Build Tools 35.0.0
- JDK 17
- Android Gradle Plugin 8.5.2 / Gradle wrapper-compatible environment

## APK output
After a successful debug build:

`app/build/outputs/apk/debug/app-debug.apk`

## Termux
If using Termux, do not install random packages or delete system directories. Set:

```bash
export ANDROID_HOME=$HOME/android-sdk
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
```

Then install only:

```bash
sdkmanager "platforms;android-35" "build-tools;35.0.0"
```

and build:

```bash
cd ~/storage/downloads/StackCallDialer_Corrected
gradle --no-daemon assembleDebug
```
