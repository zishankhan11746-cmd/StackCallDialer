package com.example.stackcalldialer

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.provider.CallLog
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val req = 10
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), req)
        else show()
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) {
        super.onRequestPermissionsResult(r,p,g); show()
    }

    private fun show() {
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,22,18,18); setBackgroundColor(Color.rgb(248,248,250))
        }
        val title=TextView(this).apply { text="Recent Calls"; textSize=30f; setTextColor(Color.BLACK); setPadding(8,8,8,22) }
        root.addView(title)
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val seen=HashSet<String>()
        val c=contentResolver.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER,CallLog.Calls.TYPE,CallLog.Calls.DATE,CallLog.Calls.CACHED_NAME),
            null,null,CallLog.Calls.DATE+" DESC")
        var count=0
        c?.use {
            val n=it.getColumnIndex(CallLog.Calls.NUMBER); val t=it.getColumnIndex(CallLog.Calls.TYPE)
            val d=it.getColumnIndex(CallLog.Calls.DATE); val name=it.getColumnIndex(CallLog.Calls.CACHED_NAME)
            while(it.moveToNext() && count<40){
                val num=it.getString(n) ?: ""; if(seen.contains(num)) continue
                seen.add(num); count++
                val card=TextView(this).apply {
                    text=(it.getString(name)?.takeIf{ x->x.isNotBlank()} ?: num)+"\n"+typeText(it.getInt(t))
                    textSize=18f; setTextColor(Color.BLACK); setPadding(22,18,22,18)
                    setBackgroundColor(Color.WHITE); elevation=8f
                    setOnClickListener { try { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:"+Uri.encode(num)))) } catch(_:Exception){} }
                }
                val lp=LinearLayout.LayoutParams(-1,100); lp.setMargins(8,0,8,-24)
                list.addView(card,lp)
            }
        }
        if(count==0) list.addView(TextView(this).apply{text="No recent calls";textSize=18f;setPadding(20,40,20,40)})
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun typeText(t:Int)=when(t){
        CallLog.Calls.MISSED_TYPE -> "Missed call"
        CallLog.Calls.OUTGOING_TYPE -> "Outgoing call"
        CallLog.Calls.INCOMING_TYPE -> "Incoming call"
        else -> "Call"
    }
}
